from django.apps import AppConfig


class DjangoTruncateConfig(AppConfig):
    name = 'django_truncate'
